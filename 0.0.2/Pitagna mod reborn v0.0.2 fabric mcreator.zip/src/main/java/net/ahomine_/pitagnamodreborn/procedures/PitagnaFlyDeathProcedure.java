package net.ahomine_.pitagnamodreborn.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;

import net.ahomine_.pitagnamodreborn.network.PitagnaModRebornModVariables;
import net.ahomine_.pitagnamodreborn.PitagnaModRebornMod;

public class PitagnaFlyDeathProcedure {
	public static boolean eventResult = true;

	public PitagnaFlyDeathProcedure() {
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			execute((Entity) newPlayer);
		});
	}

	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.getAttachedOrCreate(PitagnaModRebornModVariables.PLAYER_VARIABLES).PitagnaGemPower >= 15) {
			if (entity instanceof Player _player && !_player.level().isClientSide()) {
				_player.displayClientMessage(Component.literal(("you only have " + (entity.getAttachedOrCreate(PitagnaModRebornModVariables.PLAYER_VARIABLES).PitagnaGemPower + " Pitagna Gem power"))), true);
			}
		} else {
			if (entity instanceof Player _player) {
				_player.getAbilities().mayfly = false;
				_player.onUpdateAbilities();
			}
			PitagnaModRebornMod.LOGGER.info("pitagna fly enabled");
		}
	}
}
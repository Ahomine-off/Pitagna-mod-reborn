/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.ahomine_.pitagnamodreborn.init;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;

import net.ahomine_.pitagnamodreborn.network.PitagnaFlyMessage;

public class PitagnaModRebornModKeyMappingsServer {
	public static void serverLoad() {
		PayloadTypeRegistry.playC2S().register(PitagnaFlyMessage.TYPE, PitagnaFlyMessage.STREAM_CODEC);
		ServerPlayNetworking.registerGlobalReceiver(PitagnaFlyMessage.TYPE, PitagnaFlyMessage::handleData);
	}
}
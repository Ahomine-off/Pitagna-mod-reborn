package net.ahomine_.pitagnamodreborn;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.ClientModInitializer;

import net.ahomine_.pitagnamodreborn.network.PitagnaModRebornModVariables;
import net.ahomine_.pitagnamodreborn.init.PitagnaModRebornModKeyMappings;

@Environment(EnvType.CLIENT)
public class PitagnaModRebornModClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Start of user code block mod constructor
		// End of user code block mod constructor

		PitagnaModRebornModKeyMappings.clientLoad();
		ClientPlayNetworking.registerGlobalReceiver(PitagnaModRebornModVariables.PlayerVariablesSyncMessage.TYPE, PitagnaModRebornModVariables.PlayerVariablesSyncMessage::handleData);
		// Start of user code block mod init
		// End of user code block mod init
	}
	// Start of user code block mod methods
	// End of user code block mod methods
}
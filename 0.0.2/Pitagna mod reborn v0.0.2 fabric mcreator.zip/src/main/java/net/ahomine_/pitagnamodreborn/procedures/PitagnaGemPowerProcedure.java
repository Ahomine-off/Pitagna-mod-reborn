package net.ahomine_.pitagnamodreborn.procedures;

import net.minecraft.world.entity.Entity;

import net.ahomine_.pitagnamodreborn.network.PitagnaModRebornModVariables;

public class PitagnaGemPowerProcedure {
	public static boolean eventResult = true;

	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			PitagnaModRebornModVariables.PlayerVariables _vars = entity.getAttachedOrCreate(PitagnaModRebornModVariables.PLAYER_VARIABLES);
			_vars.PitagnaGemPower = entity.getAttachedOrCreate(PitagnaModRebornModVariables.PLAYER_VARIABLES).PitagnaGemPower + 1;
			_vars.markSyncDirty();
		}
	}
}
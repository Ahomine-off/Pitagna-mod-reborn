package net.ahomine_.pitagnamodreborn.network;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.RegistryFriendlyByteBuf;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

import net.ahomine_.pitagnamodreborn.procedures.PitagnaFlyTouchePressProcedure;
import net.ahomine_.pitagnamodreborn.PitagnaModRebornMod;

public record PitagnaFlyMessage(int eventType, int pressedms) implements CustomPacketPayload {
	public static final Type<PitagnaFlyMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(PitagnaModRebornMod.MODID, "key_pitagna_fly"));
	public static final StreamCodec<RegistryFriendlyByteBuf, PitagnaFlyMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, PitagnaFlyMessage message) -> {
		buffer.writeInt(message.eventType);
		buffer.writeInt(message.pressedms);
	}, (RegistryFriendlyByteBuf buffer) -> new PitagnaFlyMessage(buffer.readInt(), buffer.readInt()));

	@Override
	public Type<PitagnaFlyMessage> type() {
		return TYPE;
	}

	public static void handleData(final PitagnaFlyMessage message, final ServerPlayNetworking.Context context) {
		context.server().execute(() -> {
			pressAction(context.player(), message.eventType, message.pressedms);
		});
	}

	public static void pressAction(Player entity, int type, int pressedms) {
		Level world = entity.level();
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		// security measure to prevent arbitrary chunk generation
		if (!world.hasChunkAt(entity.blockPosition()))
			return;
		if (type == 0) {

			PitagnaFlyTouchePressProcedure.execute(entity);
		}
	}
}
/*
* MCreator note: This file will be REGENERATED on each build.
*/
package net.ahomine_.pitagnamodreborn.init;

import org.lwjgl.glfw.GLFW;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import net.ahomine_.pitagnamodreborn.network.PitagnaFlyMessage;

@Environment(EnvType.CLIENT)
public class PitagnaModRebornModKeyMappings {
	public static final KeyMapping PITAGNA_FLY = new KeyMapping("key.pitagna_mod_reborn.pitagna_fly", GLFW.GLFW_KEY_DELETE, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				ClientPlayNetworking.send(new PitagnaFlyMessage(0, 0));
				PitagnaFlyMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};

	public static void clientLoad() {
		KeyBindingHelper.registerKeyBinding(PITAGNA_FLY);
		ClientTickEvents.END_CLIENT_TICK.register((client) -> {
			if (client.screen == null) {
				PITAGNA_FLY.consumeClick();
			}
		});
	}
}
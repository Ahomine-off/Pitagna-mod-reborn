/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.ahomine_.pitagnamodreborn.init;

import net.ahomine_.pitagnamodreborn.procedures.PitagnaFlyDeathProcedure;

@SuppressWarnings("InstantiationOfUtilityClass")
public class PitagnaModRebornModProcedures {
	public static void load() {
		new PitagnaFlyDeathProcedure();
	}
}
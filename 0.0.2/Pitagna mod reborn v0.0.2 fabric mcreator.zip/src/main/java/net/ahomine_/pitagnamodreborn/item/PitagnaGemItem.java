package net.ahomine_.pitagnamodreborn.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;

import net.ahomine_.pitagnamodreborn.procedures.PitagnaGemPowerProcedure;

public class PitagnaGemItem extends Item {
	public PitagnaGemItem(Item.Properties properties) {
		super(properties.rarity(Rarity.RARE));
	}

	@Override
	public void onCraftedBy(ItemStack itemstack, Player entity) {
		super.onCraftedBy(itemstack, entity);
		PitagnaGemPowerProcedure.execute(entity);
	}
}
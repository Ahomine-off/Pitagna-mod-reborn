/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.ahomine_.pitagnamodreborn.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;

import net.ahomine_.pitagnamodreborn.PitagnaModRebornMod;

public class PitagnaModRebornModTabs {
	public static ResourceKey<CreativeModeTab> TAB_PITAGNA_MOD_REBORN_TAB = ResourceKey.create(Registries.CREATIVE_MODE_TAB, ResourceLocation.fromNamespaceAndPath(PitagnaModRebornMod.MODID, "pitagna_mod_reborn_tab"));

	public static void load() {
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, TAB_PITAGNA_MOD_REBORN_TAB,
				FabricItemGroup.builder().title(Component.translatable("item_group.pitagna_mod_reborn.pitagna_mod_reborn_tab")).icon(() -> new ItemStack(PitagnaModRebornModItems.PITAGNA_GEM)).displayItems((parameters, tabData) -> {
					tabData.accept(PitagnaModRebornModItems.PITAGNA_GEM);
				}).build());
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(tabData -> {
			tabData.accept(PitagnaModRebornModItems.PITAGNA_GEM);
		});
	}
}